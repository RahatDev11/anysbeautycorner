// Pages managers export
export { initializeHomePage } from './home-manager.js';
export { initializeProductDetailPage } from './product-details-manager.js';
export { initializeOrderFormPage } from './order-form-manager.js';
export { initializeOrderTrackPage } from './order-track-manager.js';
export { initializeOrderListPage } from './order-list-manager.js';